# OpenCL harness
This directory contains the wrapper code around OpenCL APIs (`ocl_src`) and top-level makefile. Part of the makefile is adapted from the Xilinx SDAccel example repository. 
