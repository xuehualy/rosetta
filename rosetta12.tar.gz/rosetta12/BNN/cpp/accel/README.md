 * Accel.h: the synthesizable accelerator code
 * AccelSchedule.h: driver functions for calling the accel to execute BNN layers
 * AccelTest.h: functions and helpers for writing test programs for the accel
 * AccelPrint.h: printing functions for weights and etc
